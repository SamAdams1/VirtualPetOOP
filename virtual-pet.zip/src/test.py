hudBars = {
    'bruh':'healthbar',
    'idc': 'dfalfj'
}
def test():
    for pair in hudBars.items():
        print(pair[0], pair[1])

# test()

randomEvents = {
    'petRan': {
        'happened': False,
        'room': 'Playroom',
    },
    'lostToy': {
        'happened': False,
        'room': "Vet",
    },
}
print(randomEvents['lostToy']['room'])